package com.foodangel;

public class GameType {
    int id;
    String type;
    boolean box;

    public GameType(int id, String type, boolean box) {
        this.id = id;
        this.type = type;
        this.box = box;
    }
}
